# Feedly はてブ Proxy

Feedly はてブ Proxy はそれ単体では動作せず、[Feedly はてブ](https://chromewebstore.google.com/detail/feedly-%E3%81%AF%E3%81%A6%E3%83%96/ggaaakgimbjhmglfoahnaoknmceipgni)という Google Chrome エクステンションと共に使う事が想定されているツールです。

詳しくは、[Feedly はてブのホームページ](https://github.com/otchy210/feedly-hatebu/blob/master/README.md)を参照してください。

